#include<iostream>
#include<string>
#include<vector>
#include<cstdlib>
using namespace std;
class Process
{
	public:
		int processNumber;
		int arrivalTime;
		int burstTime;
		int priority;

		Process();
		Process(int processNumber, int arrivalTime, int burstTime, int priority);

		int getArrivalTime();
		int getBurstTime();
		int getPriority();
		int getProcessNumber();
		void executeBurstTime();
};

///////////////////////////////Process//////////////////////////////////////
Process::Process():arrivalTime(0), burstTime(0), priority(0), processNumber(0){}

Process::Process(int processNumber, int arrivalTime, int burstTime, int priority)
:processNumber(processNumber), arrivalTime(arrivalTime), burstTime(burstTime), priority(priority){}

int Process::getArrivalTime()
{
	return arrivalTime;
}

int Process::getBurstTime()
{
	return burstTime;
}

int Process::getPriority()
{
	return priority;
}

int Process::getProcessNumber()
{
	return processNumber;
}

void Process::executeBurstTime()
{
	burstTime--;
}

/////////////////////////////Process////////////////////////////////////////


class Help
{
	public:
		vector<Process> processList;

		Help(vector<Process> processList);
		vector<Process> getProcessList();
		virtual void showGanttChart() = 0;
		void NewGchart(vector<int> outputList);
};

///////////////////////////////algorithm//////////////////////////////////////////
Help::Help(vector<Process> processList):processList(processList){}

vector<Process> Help::getProcessList()
{
	return processList;
}

void Help::NewGchart(vector<int> outputList)
{
	vector<int> timeList;
	vector<int> printedProcess;

	outputList.push_back(99);
	cout << endl;

	cout.width(2);
	cout << "|";
	for ( int i=0; i < outputList.size()-1; i++)
	{
		if ( outputList[i] != outputList[i+1])
		{
			if ( outputList[i] == -1)//idle
			{
				cout.width(2);
				cout << "X";
				printedProcess.push_back(-1);
			}
			else
			{
				cout.width(2);
				cout << "P" << outputList[i];
				printedProcess.push_back(outputList[i]);
			}

			cout.width(2);
			cout << "|";
			timeList.push_back(i+1);
		}
	}
	cout << endl;

	cout.width(2);
	cout << "0";
	for (int j=0; j < timeList.size(); j++)
	{
		if ( printedProcess[j] == -1)
		{
			cout.width(4);
			cout << timeList[j];
		}
		else
		{
			cout.width(5);
			cout << timeList[j];
		}
	}
}

///////////////////////////////////algorithm//////////////////////////////////////

class RoundRobin : public Help
{
	private:
		int Qtm;
	public:
		RoundRobin(vector<Process> processList, int Qtm);
		int getQtm();
		void showGanttChart();
};

///////////////////////////RR//////////////////////////////////////////////////////
RoundRobin::RoundRobin(vector<Process> processList, int Qtm):Help(processList)
{
	this->Qtm = Qtm;
}

int RoundRobin::getQtm()
{
	return Qtm;
}

void RoundRobin::showGanttChart()
{
	vector<Process> tempProcessList = RoundRobin::getProcessList();


	vector<Process> arrivedProcessList;
	vector<int> outputList;

	int sumOfBurstTime = 0;
	int smallestArrivalTime = 0;
	int delay = 0;
	int Qtm = RoundRobin::getQtm();

	Process highestPriorityProcess;

	for ( int i = 0; i < tempProcessList.size(); i++)
	{
		sumOfBurstTime += (tempProcessList[i]).getBurstTime();
	}
	cout << "Total burst time: " << sumOfBurstTime << endl;

	for ( int j = 0; j < (sumOfBurstTime+delay); j++)
	{

		if ( arrivedProcessList.size() < tempProcessList.size())
		{
			for ( int s=0; s < tempProcessList.size(); s++)
			{
				if ((tempProcessList[s]).getArrivalTime() == j)
				{
					arrivedProcessList.push_back(tempProcessList[s]);
				}
			}
		}

		if ( arrivedProcessList.size() != 0)
		{
			if ( Qtm == 0)
			{
				Qtm = RoundRobin::getQtm();
				arrivedProcessList.push_back(arrivedProcessList[0]);
				arrivedProcessList.erase(arrivedProcessList.begin());


				for ( int y=arrivedProcessList.size(); y > 1; y--)
				{
					for ( int x=0; x < y-1; x++)
					{
						if ((arrivedProcessList[x]).getPriority() > (arrivedProcessList[x+1]).getPriority())
						{
							arrivedProcessList.insert(arrivedProcessList.begin() + x, arrivedProcessList[x+1]);
							arrivedProcessList.erase(arrivedProcessList.begin() + (x+2));
						}
					}
				}
			}


			arrivedProcessList[0].executeBurstTime();
			outputList.push_back(arrivedProcessList[0].getProcessNumber());
			Qtm--;

			if ( arrivedProcessList[0].getBurstTime() == 0)
			{
				arrivedProcessList.erase(arrivedProcessList.begin());
				Qtm = RoundRobin::getQtm();
				continue;
			}
		}
		else
		{
			outputList.push_back(-1);

			delay++;
		}
	}
	cout << endl;
	cout << "size of arrived process : " << arrivedProcessList.size() << endl;

	for (int p=0; p < arrivedProcessList.size(); p++)
	{
		cout << arrivedProcessList[p].getBurstTime() << endl;
	}

	NewGchart(outputList);
}

//////////////////////////RR///////////////////////////////////////////////////////

class Level3 : public Help{
	private:
		int Qtm;
	public:
		Level3(vector<Process> processList, int Qtm);
		int getQtm();
		void showGanttChart();
};

/////////////////////////Three-level//////////////////////////////////////////////
Level3::Level3(vector<Process> processList, int Qtm):Help(processList)
{
	this->Qtm = Qtm;
}

int Level3::getQtm()
{
	return Qtm;
}

void Level3::showGanttChart()
{
	vector<Process> tempProcessList = Level3::getProcessList();


	vector<Process> arrivedProcessList1;
	vector<Process> arrivedProcessList2;
	vector<Process> arrivedProcessList3;
	vector<int> outputList;

	int sumOfBurstTime = 0;
	int Qtm = Level3::getQtm();
	int delay = 0;

	Process highestPriorityProcess;

	for ( int i = 0; i < tempProcessList.size(); i++)
	{
		sumOfBurstTime += (tempProcessList[i]).getBurstTime();
	}
	cout << "Total burst time: " << sumOfBurstTime << endl;


	for ( int j = 0; j < (sumOfBurstTime+delay); j++)
	{

		if ((arrivedProcessList1.size() + arrivedProcessList2.size() + arrivedProcessList3.size()) < tempProcessList.size())
		{
			for ( int s=0; s < tempProcessList.size(); s++)
			{
				if ((tempProcessList[s]).getArrivalTime() == j)
				{
					if ( (tempProcessList[s]).getPriority() == 1 || (tempProcessList[s]).getPriority() == 2)
					{
						arrivedProcessList1.push_back(tempProcessList[s]);
					}
					else if ( (tempProcessList[s]).getPriority() == 3 || (tempProcessList[s]).getPriority() == 4)
					{
						arrivedProcessList2.push_back(tempProcessList[s]);
					}
					else if ( (tempProcessList[s]).getPriority() == 5 || (tempProcessList[s]).getPriority() == 6)
					{
						arrivedProcessList3.push_back(tempProcessList[s]);
					}
				}
			}
		}


		if ( arrivedProcessList1.size() != 0)
		{
			if ( Qtm == 0)
			{
				Qtm = Level3::getQtm();
				arrivedProcessList1.push_back(arrivedProcessList1[0]);
				arrivedProcessList1.erase(arrivedProcessList1.begin());
			}


			arrivedProcessList1[0].executeBurstTime();
			outputList.push_back(arrivedProcessList1[0].getProcessNumber());
			Qtm--;

			if ( arrivedProcessList1[0].getBurstTime() == 0)
			{
				arrivedProcessList1.erase(arrivedProcessList1.begin());
				Qtm = Level3::getQtm();
				continue;
			}
		}


		else if ( arrivedProcessList2.size() != 0 && arrivedProcessList1.size() == 0)
		{

			highestPriorityProcess = arrivedProcessList2[0];
			for ( int x=0; x < arrivedProcessList2.size()-1; x++)
			{
				if ((highestPriorityProcess).getArrivalTime() <= (arrivedProcessList2[x+1]).getArrivalTime())
				{
					highestPriorityProcess = highestPriorityProcess;
				}
				else
				{
					highestPriorityProcess = arrivedProcessList2[x+1];
				}
			}

			for(int m = 0; m < arrivedProcessList2.size(); m++)
			{
				if (((highestPriorityProcess).getProcessNumber()) == ((arrivedProcessList2[m]).getProcessNumber()))
				{
					arrivedProcessList2[m].executeBurstTime();
					outputList.push_back(arrivedProcessList2[m].getProcessNumber());

					if ( arrivedProcessList2[m].getBurstTime() == 0)
					{
						arrivedProcessList2.erase(arrivedProcessList2.begin()+m);
					}
					break;
				}
			}
		}


		else if ( arrivedProcessList3.size() != 0 && arrivedProcessList1.size() == 0 && arrivedProcessList2.size() == 0)
		{

			highestPriorityProcess = arrivedProcessList3[0];
			for ( int y=0; y < arrivedProcessList3.size()-1; y++)
			{
				if ((highestPriorityProcess).getArrivalTime() <= (arrivedProcessList3[y+1]).getArrivalTime())
				{
					highestPriorityProcess = highestPriorityProcess;
				}
				else
				{
					highestPriorityProcess = arrivedProcessList3[y+1];
				}
			}

			for(int u = 0; u < arrivedProcessList3.size(); u++)
			{
				if (((highestPriorityProcess).getProcessNumber()) == ((arrivedProcessList3[u]).getProcessNumber()))
				{
					arrivedProcessList3[u].executeBurstTime();
					outputList.push_back(arrivedProcessList3[u].getProcessNumber());

					if ( arrivedProcessList3[u].getBurstTime() == 0)
					{
						arrivedProcessList3.erase(arrivedProcessList3.begin()+u);
					}
					break;
				}
			}


			for ( int w=0; w < arrivedProcessList3.size(); w++)
			{
				arrivedProcessList2.push_back(arrivedProcessList3[w]);
			}
			arrivedProcessList3.clear();
		}


		else if ((arrivedProcessList1.size()+arrivedProcessList2.size()+arrivedProcessList3.size()) == 0)
		{
			outputList.push_back(-1);

			delay++;
		}
	}
	cout << endl;
	cout << "size of arrived process : " << arrivedProcessList1.size() << endl;
	cout << "size of arrived process : " << arrivedProcessList2.size() << endl;
	cout << "size of arrived process : " << arrivedProcessList3.size() << endl;

	NewGchart(outputList);
}

///////////////////////Three-level///////////////////////////////////////////////


//--------------------------------------------------------------------------
int checkNumberOfProcess();
string chooseAlgorithm();
int checkArrivalTime();
int checkBurstTime();
int checkPriority();
int checkQtm();
void fillIn(vector<Process>& listOfProcess, int NumberOfProcess, string algo, int& Qtm);
void display(vector<Process> listOfProcess, int NumberOfProcess, string algo, int Qtm);
void displayGanttChart(string algo, vector<Process> listOfProcess, int Qtm);
//--------------------------------------------------------------------------
int main(){

	int Qtm;

	string algo = chooseAlgorithm();
	cout << "we are choosing " << algo << " algorithm\n";

	int NumberOfProcess = checkNumberOfProcess();
	cout << "we have " << NumberOfProcess << " processes\n";

	vector<Process> listOfProcess(NumberOfProcess);

	fillIn(listOfProcess, NumberOfProcess, algo, Qtm);

	display(listOfProcess, NumberOfProcess, algo, Qtm);

	displayGanttChart(algo, listOfProcess, Qtm);





}
//--------------------------------------------------------------------------
int checkNumberOfProcess()
{
    int numberOfProcess;
	int correct = 0;
	int minNumberOfProcess = 3;
	int maxNumberOfProcess = 10;
    while (correct == 0)
    {
        cout << "Please enter the number of process (3-10) : ";
        while (!(cin >> numberOfProcess))
        {
            cout << "Invalid input !\nPlease enter in integer form.\a\n\n";
            cin.clear();
            cin.ignore(100,'\n');
			cout << "Please enter the number of process (3-10) : ";
        }
        if (numberOfProcess >= minNumberOfProcess)
        {
            if (numberOfProcess <= maxNumberOfProcess)
            {
                cout << endl;
                correct = 1;
            }
            else
            {
                cout << "Number entered is not in the range (3-10)\a\n\n";
                correct = 0;
            }
        }
        else
        {
            cout << "Number entered is not in the range (3-10)\a\n\n";
            correct = 0;
        }
    }
    return numberOfProcess;
}
//--------------------------------------------------------------------------
string chooseAlgorithm()
{
	int num;
	int correct = 0;
	string algorithm;

	while (correct == 0)
	{
		cout << "Please choose the scheduling alogorithm" << endl;
		cout << "1. Round Robin Scheduling with Priority " << endl;
		cout << "2. Three-level Queue Scheduling " << endl;

		cin >> num;

		switch (num)
		{
			case 1:
				algorithm = "RR";
				correct = 1;
				break;
			case 2:
				algorithm = "3LVL";
				correct = 1;
				break;

			default:
				cout << "Invalid input !\a\n\n";
				correct = 0;
				cin.clear();
				cin.ignore(100,'\n');
		}
	}
	return algorithm;
}
//--------------------------------------------------------------------------
int checkArrivalTime()
{
    int arrivalTime;
	int correct = 0;

    while ( correct == 0)
	{
		cout << "Arrival Time : ";
		while (!(cin >> arrivalTime))
		{
			cout << "Invalid input !\nPlease enter in integer form.\a\n\n";
			cin.clear();
			cin.ignore(100,'\n');
			cout << "Arrival Time : ";
		}
		if (arrivalTime >= 0)
		{
			cout << endl;
			correct = 1;
		}
		else
		{
			cout << "Invalid arrival time !\a\n\n";
			correct = 0;
		}
	}
    return arrivalTime;
}
//--------------------------------------------------------------------------
int checkBurstTime()
{
    int burstTime;
	int correct = 0;

    while ( correct == 0)
	{
		cout << "Burst Time : ";
		while (!(cin >> burstTime))
		{
			cout << "Invalid input !\nPlease enter in integer form.\a\n\n";
			cin.clear();
			cin.ignore(100,'\n');
			cout << "Burst Time : ";
		}
		if (burstTime > 0)
		{
			cout << endl;
			correct = 1;
		}
		else
		{
			cout << "Invalid burst time !\a\n\n";
			correct = 0;
		}
	}
    return burstTime;
}
//--------------------------------------------------------------------------
int checkPriority()
{
    int priority;
	int correct = 0;
	int minPriority = 1;
	int maxPriority = 10;
    while (correct == 0)
    {
        cout << "Priority (1-10) : ";
        while (!(cin >> priority))
        {
            cout << "Invalid input !\nPlease enter in integer form.\a\n\n";
            cin.clear();
            cin.ignore(100,'\n');
			cout << "Priority (1-10) : ";
        }
        if (priority >= minPriority)
        {
            if (priority <= maxPriority)
            {
                cout << endl;
                correct = 1;
            }
            else
            {
                cout << "Number entered is not in the range (1-6)\a\n\n";
                correct = 0;
            }
        }
        else
        {
            cout << "Number entered is not in the range (1-6)\a\n\n";
            correct = 0;
        }
    }
    return priority;
}
//--------------------------------------------------------------------------
int checkQtm()
{
    int Qtm;
	int correct = 0;

    while ( correct == 0)
	{
		cout << "Time Qtm (1-10) : ";
		while (!(cin >> Qtm))
		{
			cout << "Invalid input !\nPlease enter in integer form.\a\n\n";
			cin.clear();
			cin.ignore(100,'\n');
			cout << "Time Quantum (1-10) : ";
		}
		if (Qtm > 0 && Qtm <= 10)
		{
			cout << endl;
			correct = 1;
		}
		else
		{
			cout << "Invalid time quantum! \a\n\n";
			correct = 0;
		}
	}
    return Qtm;
}
//--------------------------------------------------------------------------
void fillIn(vector<Process>& listOfProcess,int NumberOfProcess, string algo, int& Qtm)
{
	int a, b, p;
	int largestArrivalTime = 0, totalBurstTime = 0;

	for ( int i = 0; i < NumberOfProcess; i++)
	{
		cout << "Process " << i+1 << endl;
		a = checkArrivalTime();
		b = checkBurstTime();
		p = checkPriority();
		listOfProcess[i] = (Process(i,a,b,p));
	}

	if (algo == "RR" || algo == "3LVL")
	{
		Qtm = checkQtm();
	}
}
//--------------------------------------------------------------------------
void display(vector<Process> listOfProcess, int NumberOfProcess, string algo, int Qtm)
{
	cout << "...................................................\n\n";
	cout.width(8);
	cout << "Process";
	cout.width(13);
	cout << "Burst Time";
	cout.width(15);
	cout << "Arrival Time";
	cout.width(11);
	cout << "Priority";
	cout << endl;
	cout << " _______   __________   ____________   ________" << endl;
	for ( int i = 0; i < NumberOfProcess; i++ )
	{
		cout.width(5);
		cout << "P" << listOfProcess[i].getProcessNumber();
		cout.width(11);
		cout << listOfProcess[i].getBurstTime();
		cout.width(14);
		cout << listOfProcess[i].getArrivalTime();
		cout.width(13);
		cout << listOfProcess[i].getPriority();
		cout << endl;
	}
	if ( algo == "RR" || algo == "3LVL")
	{

		cout << "(Quantum : " << Qtm << ")\n\n";
	}
}
//--------------------------------------------------------------------------
void displayGanttChart(string algo, vector<Process> listOfProcess, int Qtm)
{
	Help *a;

	if ( algo == "RR" )
	{
		a = new RoundRobin(listOfProcess, Qtm);
	}
	else if ( algo == "3LVL" )
	{
		a = new Level3(listOfProcess, Qtm);
	}

	a->showGanttChart();
}
