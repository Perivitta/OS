#include <iostream>
#include <sstream>
#include <vector>
#include <iomanip>
using namespace std;

void getInt(int& toGet);    //Force get integer
void inBetween(int& toCheck, int fromLimit);    //Force get integer in from a specific num
void inBetween(int& toCheck, int fromLimit, int toLimit);   // Force get integer in a range
void getIntoVector(string caption, vector<int>& vectorToPush, int fromLimit, int counter);  //Get one information of a process that has only bottom limit
void getIntoVector(string caption, vector<int>& vectorToPush, int fromLimit, int toLimit, int counter);     //Get one information of a process that has range
void printInputTable(vector<int> arrivalTimeArray, vector<int> priority, vector<int> burstTime, int row);   //Print all the input of users
void printGanttChart(vector<int> ganttChart);   //Print output(Gantt Chart)
void singleLevel(vector<int> arrivalTimeArray, vector<int> priority, vector<int> burstTime, int numOfProcess, int mode);
void multiLevel(vector<int> arrivalTimeArray, vector<int> priority, vector<int> burstTime, int numOfProcess);
bool checkCase(vector<int> queueListToCheck, vector<int> arrivalTimeArray, int currentTime, vector<int> leftBurstTime, vector<int>& indexGroup);

int main()
{
    int counter = 0;
    int numOfProcess;
    vector<int> arrivalTimeArray;
    vector<int> priority;
    vector<int> burstTime;
    int quantum;

    cout << "--------------------------------------" << endl;
    cout << "|     CPU Scheduling Algorithm       |" << endl;
    cout << "--------------------------------------" << endl << endl;

    cout << "Number of Process(3~10): ";
    getInt(numOfProcess);
    inBetween(numOfProcess, 3, 10);
    cout << endl;

    while (counter < numOfProcess)
    {
        getIntoVector("Burst Time", burstTime, 1, counter);
        getIntoVector("Arrival Time", arrivalTimeArray, 0, counter);
        getIntoVector("Priority", priority, 1, 6, counter);
        cout << endl;
        //printInputTable(arrivalTimeArray, priority, burstTime, counter);
        counter++;
    }

    cout << endl;
    printInputTable(arrivalTimeArray, priority, burstTime, counter);

    singleLevel(arrivalTimeArray, priority, burstTime, numOfProcess, 1);  //FCFS with priority
    singleLevel(arrivalTimeArray, priority, burstTime, numOfProcess, 2);  //RR
    multiLevel(arrivalTimeArray, priority, burstTime, numOfProcess); //3lvl queue
    singleLevel(arrivalTimeArray, priority, burstTime, numOfProcess, 3); //SRTN

    return 0;
}

void getInt(int& toGet)
{
  try
  {
    string tryGet;
    getline(cin,tryGet);                 //Get string
    if (!(istringstream (tryGet) >> toGet))     //If convert not success
    {
      throw tryGet;                             //Throw
    }
  }
  catch (string s)                              //Catch and return false
  {
    cout << "Invalid input! Please enter integer: ";
    getInt(toGet);
  }
}

void inBetween(int& toCheck, int fromLimit)
{
    while (toCheck < fromLimit)
    {
        cout << "Invalid input! Please enter integer >=" << fromLimit << ": ";
        getInt(toCheck);
    }
}

void inBetween(int& toCheck, int fromLimit, int toLimit)  //use for number of process
{
    while ((toCheck < fromLimit) or (toCheck > toLimit))
    {
        cout << "Invalid input! Please enter integer in between " << fromLimit << '~' << toLimit << ": ";
        getInt(toCheck);
    }
}

void getIntoVector(string caption, vector<int>& vectorToPush, int fromLimit, int counter)  //arrivalTimeArray & burstTime
{
    int temp;
    cout << "Process "<< counter << "'s " << caption << ": ";
    getInt(temp);
    inBetween(temp,fromLimit);
    vectorToPush.push_back(temp);
}

void getIntoVector(string caption, vector<int>& vectorToPush, int fromLimit, int toLimit, int counter) //priority
{
    int temp;
    cout << "Process "<< counter << "'s " << caption << ": ";
    getInt(temp);
    inBetween(temp,fromLimit, toLimit);
    vectorToPush.push_back(temp);
}

void printInputTable(vector<int> arrivalTimeArray, vector<int> priority, vector<int> burstTime, int row)
{
    cout << "--------------------------------------------" << endl
         << '|' << setw(7) << "Process" << '|' << setw(12) << "Burst Time" << '|' << setw(12) << "Arrival Time"
         << '|' << setw(8) << "Priority" << '|' << endl
         << "--------------------------------------------" << endl;
    for (int i = 1; i <= row; i++)
    {
        cout << '|' << setw(6) << 'P' << (i-1) << '|' << setw(12) << burstTime[i-1] << '|' << setw(12) << arrivalTimeArray[i-1]
             << '|' << setw(8) << priority[i-1] << '|' << endl;
    }
    cout << "--------------------------------------------" << endl << endl << endl;
}

void multiLevel(vector<int> arrivalTimeArray, vector<int> priority, vector<int> burstTime, int numOfProcess)
{
    cout << endl << "Enter quantum for round robin(First queue of 3-level): " ;

    int quantum;
    getInt(quantum);
    inBetween(quantum, 1);

    cout << "3-Level Queue (quantum = " << quantum << ")" << endl;

    int currentTime = 0;
    vector<int> ganttChartOne;
    vector<int> ganttChartTwo;
    vector<int> ganttChartThree;
    vector<int> leftBurstTime(burstTime);
    vector<int> queueListOne;
    vector<int> queueListTwo;
    vector<int> queueListThree;
    vector<bool> doneOnce;

    for (int i = 0; i < numOfProcess; i++)
    {
        doneOnce.push_back(false);
    }
    int doneProcess = 0;

    //split to different queue
    for (int i = 0; i < numOfProcess; i++)
    {
        if (priority[i] <= 2)
        {
            queueListOne.push_back(i);
        }
        else if (priority[i] <= 4)
        {
            queueListTwo.push_back(i);
        }
        else
        {
            queueListThree.push_back(i);
        }
    }

    //If there are no processes in queue 2,
    //those in queue 3 will be elevated to queue 2.
    int queueListTwoSize = queueListTwo.size();
    if (queueListTwoSize == 0)
    {
        queueListTwo = queueListThree;
        queueListThree.clear();
    }

    vector<int> indexGroup;

    while (true)
    {
        bool caseFirstQueue = checkCase(queueListOne,arrivalTimeArray,currentTime,leftBurstTime,indexGroup);
        bool caseSecondQueue = false;
        bool caseThirdQueue = false;

        if (caseFirstQueue)
        {
            caseSecondQueue = false;
            caseThirdQueue = false;
        }
        else //if (!caseFirstQueue)
        {
            caseSecondQueue = checkCase(queueListTwo,arrivalTimeArray,currentTime,leftBurstTime,indexGroup);
            if (!caseSecondQueue)
            {
                caseThirdQueue = checkCase(queueListThree,arrivalTimeArray,currentTime,leftBurstTime,indexGroup);
            }
        }

        if ((caseFirstQueue) || (caseSecondQueue) || (caseThirdQueue))
        {
            int toProcess;
            toProcess = indexGroup[0];
            int arriveSize = indexGroup.size();

            if (arriveSize >= 2)
            {
                for (int i = 1; i < arriveSize; i++)
                {
                    int processCompare = indexGroup[i];
                    bool condition = (priority[processCompare] < priority[toProcess]);
                    condition = (condition || ((priority[processCompare] == priority[toProcess]) && (arrivalTimeArray[processCompare] < arrivalTimeArray[toProcess])));

                    if ((priority[processCompare] == priority[toProcess]) && (arrivalTimeArray[processCompare] == arrivalTimeArray[toProcess]))
                    {
                        condition = condition || (leftBurstTime[processCompare] < leftBurstTime[toProcess]);
                        if (doneOnce[toProcess])
                        {
                            condition = true;
                        }
                    }

                    if (condition)
                    {
                        toProcess = processCompare;
                    }
                }
            }

            if (caseFirstQueue)
            {
                int burst;

                if (leftBurstTime[toProcess] <= quantum)
                {
                    burst = leftBurstTime[toProcess];
                    doneProcess++;
                }
                else
                {
                    burst = quantum;
                }

                for (int i = 1; i <= burst; i++)
                {
                    ganttChartOne.push_back(toProcess);
                    ganttChartTwo.push_back(-1);
                    ganttChartThree.push_back(-1);
                }

                leftBurstTime[toProcess] = leftBurstTime[toProcess] - burst;
                currentTime = currentTime + burst;
                doneOnce[toProcess] = true;
                arrivalTimeArray[toProcess] = currentTime;
            }
            else if (caseSecondQueue)
            {
                ganttChartOne.push_back(-1);
                ganttChartTwo.push_back(toProcess);
                ganttChartThree.push_back(-1);
                leftBurstTime[toProcess] = leftBurstTime[toProcess] - 1;
                if (leftBurstTime[toProcess] == 0)
                {
                    doneProcess = doneProcess + 1;
                }
                currentTime = currentTime + 1;
            }
            else
            {
                ganttChartOne.push_back(-1);
                ganttChartTwo.push_back(-1);
                ganttChartThree.push_back(toProcess);
                leftBurstTime[toProcess] = leftBurstTime[toProcess] - 1;
                if (leftBurstTime[toProcess] == 0)
                {
                    doneProcess = doneProcess + 1;
                }
                currentTime = currentTime + 1;
            }

            if (doneProcess == numOfProcess)
            {
                break;
            }
        }
        else
        {
            ganttChartOne.push_back(-1);
            ganttChartTwo.push_back(-1);
            ganttChartThree.push_back(-1);
            currentTime++;
        }
    }

    cout << "Queue 1" << endl;
    printGanttChart(ganttChartOne);
    cout << "Queue 2" << endl ;
    printGanttChart(ganttChartTwo);
    cout << "Queue 3" << endl;
    printGanttChart(ganttChartThree);
}

bool checkCase(vector<int> queueListToCheck, vector<int> arrivalTimeArray, int currentTime, vector<int> leftBurstTime, vector<int>& indexGroup)
{
    indexGroup.clear();
    bool caseChecking = false;
    if (!queueListToCheck.empty())
    {
        for (int i = 0; i < queueListToCheck.size(); i++)
        {
            if ((arrivalTimeArray[queueListToCheck[i]] <= currentTime) && (leftBurstTime[queueListToCheck[i]] > 0))
            {
                indexGroup.push_back(queueListToCheck[i]);
                caseChecking = true;
            }
        }
    }
    return caseChecking;
}

void singleLevel(vector<int> arrivalTimeArray, vector<int> priority, vector<int> burstTime, int numOfProcess, int mode)
{
    int quantum = 1;
    if (mode == 2)
    {
        cout << endl << "Enter quantum for round robin: " ;
        getInt(quantum);
        inBetween(quantum, 1);
        cout << "RR with priority" << " (quantum = " << quantum << ")" << endl;
    }
    else if (mode == 1)
    {
        cout << endl << "FCFS with priority:" << endl;
    }
    else
    {
        cout << endl << "SRTN:" << endl;
    }

    int currentTime = 0;
    vector<int> ganttChart;
    vector<int> leftBurstTime(burstTime);  //copy of vector of burstTime
    vector<int> queueList;
    vector<bool> doneOnce;

    for (int i = 0; i < numOfProcess; i++)
    {
        doneOnce.push_back(false); //alll havent done
    }
    int doneProcess = 0;

    while (true)
    {
        queueList.clear();
        for (int i = 0; i < numOfProcess; i++)
        {
            //currently, list the processes that are in queue (for process that have arrived and not yet finish bursting)
            if ((arrivalTimeArray[i] <= currentTime) && (leftBurstTime[i] > 0))
            {
                queueList.push_back(i);
            }
        }

        int queueSize = queueList.size(); //determine the number of processes in queue

        if (queueSize == 0)
        {
            ganttChart.push_back(-1); //no process waiting at that moment
            currentTime += 1;
            //then run the loop again and check on nxt t
        }
        else
        {
            int toProcess;
            toProcess = queueList[0];

            if (queueSize >= 2)  //need to compare
            {
                for (int i = 1; i < queueSize; i++)  //start compare with the next one
                {
                    int processCompare = queueList[i];
                    bool condition;
                    if (mode != 3) //either FCFS or RR
                    {
                        //if condition is true, processCompare will be the executing process
                        condition = (priority[processCompare] < priority[toProcess]); //is nxt process priority higher?
                        condition = (condition || ((priority[processCompare] == priority[toProcess]) && (arrivalTimeArray[processCompare] < arrivalTimeArray[toProcess]))); //is nxt process arrive earlier?
                        if ((priority[processCompare] == priority[toProcess]) && (arrivalTimeArray[processCompare] == arrivalTimeArray[toProcess])) // both priority & arrivalTimeArray same
                        {
                            condition = condition || (leftBurstTime[processCompare] < leftBurstTime[toProcess]); //compare their leftBurstTime
                            if ((mode == 2) && (doneOnce[toProcess])) //RR
                            {
                                condition = true;
                            }
                        }
                    }
                    else
                    {
                        condition = ((leftBurstTime[processCompare] < leftBurstTime[toProcess]) ||
                                     ((leftBurstTime[processCompare] == leftBurstTime[toProcess]) &&
                                      (priority[processCompare] < priority[toProcess])));
                    }

                    if (condition)
                    {
                        toProcess = processCompare;
                    }
                }
            }

            int burst;

            //compare ori/remaining burstTime with quantum
            if (leftBurstTime[toProcess] <= quantum) //completed
            {
                burst = leftBurstTime[toProcess];
                doneProcess++;
            }
            else
            {
                burst = quantum;  //not yet completed, just completed a quantum t
            }

            for (int i = 1; i <= burst; i++)
            {
                ganttChart.push_back(toProcess); //for each t
            }

            leftBurstTime[toProcess] = leftBurstTime[toProcess] - burst;
            currentTime = currentTime + burst;

            if (mode==2)
            {
                doneOnce[toProcess] = true;
                arrivalTimeArray[toProcess] = currentTime;
            }
        }

        if (doneProcess == numOfProcess)
            break;  //break the whole while loop -> print the Gantt Chart

    }
    printGanttChart(ganttChart);
}

void printGanttChart(vector<int> ganttChart)
{
    //first line "--------"
    for (int i = 1; i <= ganttChart.size(); i++)
    {
        cout << "----";    //every t
    }
    cout << '-' << endl << '|';  //last t  + first | in 2nd line

    //second line "process with | "
    for (int i = 1; i <= ganttChart.size(); i++)
    {
        cout << setw(2);  //one space for process num
        if (ganttChart[i-1] == ganttChart[i])
        {
            cout << "    ";
        }
        else
        {
            if (ganttChart[i-1] == -1)  //no process
            {
                cout << "  X" << '|';
            }
            else
            {
                cout << "P" << (ganttChart[i-1]) << '|';
            }
        }
    }
    cout << endl;

    //third line "------"
    for (int i = 1; i <= ganttChart.size(); i++)
    {
        cout << "----";
    }
    cout << '-' << endl << '0'; //0 is first t

    //last line: t
    for (int i = 1; i <= ganttChart.size(); i++)
    {
        cout << setw(4) << i;
    }
    cout << endl << endl;
}
